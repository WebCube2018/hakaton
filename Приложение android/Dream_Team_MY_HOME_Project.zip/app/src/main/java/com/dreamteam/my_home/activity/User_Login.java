package com.dreamteam.my_home.activity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

import com.dreamteam.my_home.MainActivity;
import com.dreamteam.my_home.R;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class User_Login extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_login);


        webView = (WebView) findViewById(R.id.webViewLogin);

        final SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh01);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                webView.reload();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        swipeRefreshLayout.setColorSchemeResources(
                android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light
        );


        WebSettings settings = webView.getSettings();
        webView.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setBackgroundColor(Color.parseColor("#FFFFFF"));
        settings.setJavaScriptEnabled(true);

        String url = "http://donets-partners.ru/lk/";
        webView.loadUrl(url);

        // ВЫХОД
        Button buttonExit = (Button) findViewById(R.id.buttonExit);
        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endActivity();
            }
        });

        Button buttonNewVote = (Button) findViewById(R.id.buttonNewVote);
        buttonNewVote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(User_Login.this, View_All_Activity.class);
                intent.putExtra("url", "http://donets-partners.ru/tema/");
                intent.putExtra("caption", "Добавить тему:");
                startActivity(intent);
            }
        });

        Button buttonResult = (Button) findViewById(R.id.buttonResult);
        buttonResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(User_Login.this, View_All_Activity.class);
                intent.putExtra("url", "http://donets-partners.ru/result/");
                intent.putExtra("caption", "Результаты:");
                startActivity(intent);
            }
        });

        Button vote = (Button) findViewById(R.id.vote);
        vote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(User_Login.this, View_All_Activity.class);
                intent.putExtra("url", "http://donets-partners.ru/golos/");
                intent.putExtra("caption", "Голосование:");
                startActivity(intent);
            }
        });

        Button buttonProfile = (Button) findViewById(R.id.buttonProfile);
        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewHelp("Отображается страница с данными профиля");
            }
        });

    }

    private void viewHelp(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void endActivity() {
        this.finish();
    }

    @Override
    protected void onResume() {
        webView.reload();
        super.onResume();
    }

}