package com.dreamteam.my_home.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import com.dreamteam.my_home.R;

public class View_All_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_view_all_activity);


        final WebView webView = (WebView) findViewById(R.id.webViewLogin);

        final SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh01);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                webView.reload();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        swipeRefreshLayout.setColorSchemeResources(
                android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light
        );


        WebSettings settings = webView.getSettings();
        webView.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        // settings.setDefaultFontSize(15);
        webView.setBackgroundColor(Color.parseColor("#FFFFFF"));
        settings.setJavaScriptEnabled(true);

        TextView textCaption = (TextView) findViewById(R.id.textCaption);
        textCaption.setText(getIntent().getStringExtra("caption"));

        final String url = getIntent().getStringExtra("url");

        webView.setWebViewClient(new WebViewClient());

        EditorInfo outAttrs = new EditorInfo();
        outAttrs.imeOptions = outAttrs.inputType | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        webView.onCreateInputConnection(outAttrs);
        webView.loadUrl(url);


        Button buttonBack = (Button) findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endActivity();
            }
        });
    }

    private void endActivity() {
        this.finish();
    }
}